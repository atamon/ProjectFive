package com.jme3.system;

public class JmeVersion {
    public static final String FULL_NAME = "jMonkeyEngine 3.0.0 Beta";
}
