/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jme3tools.navigation;

/**
 *
 * @author normenhansen
 */
public class InvalidPositionException extends Exception{

}
